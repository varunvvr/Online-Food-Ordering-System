




let order_id_emp=sessionStorage.getItem('order_id_emp');

fetch(`/ordersitemstableemp?order_id=${order_id_emp}`)
    .then(response => response.text())
    .then(htmlContent => {
    console.log(htmlContent); 
    
    const container = document.querySelector(".order_table");
    container.innerHTML = htmlContent;

    let itemvalueEles=document.querySelectorAll(".item_value");
    let totalcost=0;
    itemvalueEles.forEach(item=>{
        totalcost+=parseInt(item.textContent);
    });

   document.querySelector(".total_value").textContent=totalcost;

 });

 
 fetch(`/fetchcustomerdetails?order_id=${order_id_emp}`)
    .then(response => response.text())
    .then(htmlContent => {
    console.log(htmlContent); 
    
    const container = document.querySelector(".member-info");
    container.innerHTML = htmlContent;
   // document.querySelector(".acceptbtn").removeAttribute("onclick");
    document.querySelector(".receivedbtn").removeAttribute("onclick");
    document.querySelector(".deliveredbtn").removeAttribute("onclick");

 });


 function changeorderstatus(each_button){
    let statusvalue=each_button.value;
    console.log(statusvalue);
    
    if(statusvalue==="ACCEPT"){
        // let ele=document.querySelector(".acceptbtn");
        
        // ele.style.backgroundColor='orangered';
        // ele.removeAttribute("onclick");
        each_button.style.backgroundColor='orangered';
        each_button.removeAttribute("onclick");

        document.querySelector(".receivedbtn").setAttribute("onclick", "changeorderstatus(this)");
    }
    else if(statusvalue==="RECEIVED"){
        //let eles = each_button.parentElement.parentElement.querySelectorAll(".acbtn");
        // eles.forEach(item => {
        // item.style.backgroundColor = 'orangered';
        // item.removeAttribute("onclick");
        // });
        // let each_ele;
        // let elearray=[".acceptbtn",".receivedbtn",".deliveredbtn"];
        // elearray.forEach(item=>{
        //     each_ele=document.querySelector(item);
        //     each_ele.style.backgroundColor='orangered';
        //     each_ele.removeAttribute("onclick");
        // });
        each_button.style.backgroundColor='orangered';
        each_button.removeAttribute("onclick");
        document.querySelector(".deliveredbtn").setAttribute("onclick", "changeorderstatus(this)");
    }
    else{
        each_button.style.backgroundColor='orangered';
        each_button.removeAttribute("onclick");
    }
        
    
    fetch(`/changeorderstatus?order_id=${order_id_emp}&order_status=${statusvalue}`)
    .then(response => response.text())
    .then(status =>{
        if(status){
            console.log(status);
            
        }
    })
    .catch(error =>{
        console.error('Error:', error);
    });
 }

 function logout(){
    window.location.href="loginpage.html"
 }
 function tracklocation(){
    let combineaddress=document.querySelector(".member-address").textContent;
    const parts = combineaddress.split(": ");
    const location = parts[1];
    console.log(location);
    window.open(`https://www.google.com/maps/dir/?api=1&origin=Current+Location&destination=${location}`, '_blank');
 }