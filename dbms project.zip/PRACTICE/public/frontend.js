// frontend.js



// Make an AJAX request to fetch the HTML content
function button(){
    fetch("/data")
    .then(response => response.text())
    .then(htmlContent => {
        // Insert the HTML content into a container element
        const container = document.getElementById("container");
        container.innerHTML = htmlContent;
    })
    .catch(error => {
        console.error("Error:", error);
    });

}

// cart value



function signUp(){
    document.getElementById('signupForm').addEventListener('submit', function(event) {
        event.preventDefault();
        var radios = document.getElementsByName('user-type');
        var userType;
        for (var i = 0; i < radios.length; i++) {
            if (radios[i].checked) {
                userType = radios[i].value;
                break;
            }
        }
        var username=document.getElementById('username').value;
        var password=document.getElementById('password').value;
        var signUpData={
            "role":userType,
            "username":username,
            "password":password
        };
        const info=JSON.stringify(signUpData);
        console.log(typeof(info));
        fetch('/signUp', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: info
        })
        .then(response => response.text())
        .then(status => {
          if (status==="insertion Success"){
            alert("signup successful");
            sessionStorage.setItem('role',userType);
            if(userType!="admin"){
              sessionStorage.setItem('emp_id', username);
            }else{
              sessionStorage.setItem('user_id', username);
            }
            window.location.href = "/userpersonaldetails.html";
          }
          else{
            alert("details already exists");
            window.location.href = "/signup_page.html";
          }
        })
        .catch(error => {
          console.error('Error:', error);
        });
      });
    }   

function submitdetails(){
  
  let formelement=document.querySelectorAll('.form-control');
  let role=sessionStorage.getItem('role');
  let name=document.getElementById('full-name').value;
  let address=document.getElementById('address').value;
  let phone=document.getElementById('phone').value;
  let genderdropdown = document.getElementById("gender");
  let gender = genderdropdown.options[genderdropdown.selectedIndex].value;
  let user_id;
  if(role!="admin"){
     user_id=sessionStorage.getItem('emp_id');
  }else{
     user_id=sessionStorage.getItem('user_id');
  }
  console.log(user_id,name,address,phone,gender,role);
  fetch(`/addlogindetails?role=${role}&user_id=${user_id}&name=${name}&address=${address}&phone=${phone}&gender=${gender}`)
    .then(response => response.text())
    .then(status => {
        if (status){
            console.log(status);
            window.location.href = "/front.html";
        }
    })
    .catch(error => {
        console.error('Error:', error);
    });
}

function checklogin(){
    document.getElementById('loginForm').addEventListener('submit', function(event) {
        event.preventDefault();
        var radios = document.getElementsByName('user-type');
        var userType;
        for (var i = 0; i < radios.length; i++) {
            if (radios[i].checked) {
                userType = radios[i].value;
                break;
            }
        }
        var username=document.getElementById('username').value;
        var password=document.getElementById('password').value;
        var loginData={
            "role":userType,
            "username":username,
            "password":password
        };
        
        console.log(typeof(info));
        fetch('/login', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(loginData)
        })
        .then(response => response.text())
        .then(status => {
          console.log(status);
          if(status==="invalid"){
            alert("invalid entry");
            window.location.href = "/loginpage.html";
          }else{
            if(userType!="admin"){
              sessionStorage.setItem('emp_id', status);
              alert("entry success");
              window.location.href = "/employee.html";
            }else{
              sessionStorage.setItem('user_id', status);
              alert("entry success");
              window.location.href = "/front.html";
            }  
          }
        })
        .catch(error => {
          console.error('Error:', error);
        });
      });
}
  

