// Set initial status




let user_id=sessionStorage.getItem('user_id');
let order_id;
let intervalId;
    fetch(`/checkout?user_id=${user_id}`)
    .then(response => response.text())
    .then(htmlContent => {
    console.log(htmlContent); 
    
    const container = document.querySelector(".order_table");
    container.innerHTML = htmlContent;
    let itemvalueEles=document.querySelectorAll(".item_value");
    let totalcost=0;
    itemvalueEles.forEach(item=>{
        totalcost+=parseInt(item.textContent);
    });
    document.querySelector(".total_cost").textContent=totalcost.toString();
 })
.catch(error => {
    console.error("Error:", error);
});

function confirm(button){
    button.removeAttribute("onclick");
    let orderinfoEle=document.querySelector(".orderdetails");
    orderinfoEle.style.visibility="visible";

    fetch(`/addtoorder?user_id=${user_id}`)
        .then(response => response.text())
        .then(status => {
            if (status){
                console.log("order_id is",status);
                order_id=status;
                intervalId=setInterval(refresh, 1000);
                
            }
        })
        .catch(error => {
            console.error('Error:', error);
        });

        

    
}

function empdetails(){
  console.log("enetered into the function")
  fetch(`/fetchempdetails?order_id=${order_id}`)
        .then(response => response.text())
        .then(htmlContent => {
        console.log(htmlContent); 
        
        const container = document.querySelector(".member-info");
        container.innerHTML = htmlContent;
    
     });
}

let currentStatus = 0;

// Update status based on user input (e.g., order processed)
function updateStatus(newStatus) {
  currentStatus = newStatus;
  updateUI();
}

// Update UI based on current status
function updateUI() {
  const circles = document.querySelectorAll(".status-circle");
  circles.forEach((circle, index) => {
    if (index < currentStatus) {
      circle.style.backgroundColor = "orangered"; // Change to active color
    } else {
      circle.style.backgroundColor = "#ccc"; // Change back to default color
    }
  });

  const labels = document.querySelectorAll(".status-label");
  labels.forEach((label, index) => {
    if (index === currentStatus) {
      label.classList.add("active"); // Add active class to current status label
    } else {
      label.classList.remove("active"); // Remove active class from other labels
    }
  });
}





function refresh(){
  fetch(`/orderstatuscus?order_id=${order_id}`)
    .then(response => response.text())
    .then(status =>{
        if(status==="ACCEPT"){
          updateStatus(1);
          empdetails();
        }
        else if(status==="RECEIVED"){
          updateStatus(2);
        }else if(status==="DELIVERED"){
          updateStatus(3);
          clearInterval(intervalId);
          console.log('Interval stopped');
        }
    })
    .catch(error =>{
        console.error('Error:', error);
    });
}

function gotohome(){
  window.location.href="front.html"
}