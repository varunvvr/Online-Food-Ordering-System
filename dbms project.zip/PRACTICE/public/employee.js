let emp_id=sessionStorage.getItem('emp_id');

fetch(`/orderslistemp`)
    .then(response => response.text())
    .then(htmlContent => {
    console.log(htmlContent); 
    
    const container = document.querySelector(".container");
    container.innerHTML = htmlContent;
    
 });

 function fetchorderdetails(button){
    let orderidforemp=button.parentElement.id;
    console.log(orderidforemp);
    sessionStorage.setItem('order_id_emp',orderidforemp);
    fetch(`/orderaccept?emp_id=${emp_id}&order_id=${orderidforemp}`)
    .then(response => response.text())
    .then(status =>{
        if(status){
            console.log(status);
        }
    })
    .catch(error =>{
        console.error('Error:', error);
    });
    window.location.href="customerdelivery.html";
 }
