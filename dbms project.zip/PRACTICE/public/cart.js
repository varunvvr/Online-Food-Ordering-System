let user_id=sessionStorage.getItem('user_id');

fetch(`/cartlist?user_id=${user_id}`)
.then(response => response.text())
.then(htmlContent => {
    console.log(htmlContent); 
    // Insert the HTML content into a container element
    const container = document.querySelector(".cart-container");
    container.innerHTML = htmlContent;
    updatetotalprice();
    // Redirect to another page
    //rest_name(id);
    //cart_value(user_id);
    
 })
.catch(error => {
    console.error("Error:", error);
});

function updatetotalprice(){
    var itemsprices=document.querySelectorAll(".cart-item-price");
    let totalprice=0;
    itemsprices.forEach(price=>{
        totalprice+=parseInt(price.textContent);
    });
    document.querySelector(".cart-subtotal").textContent="Total Price : "+totalprice.toString();
}


function increaseQuantity(button){
    let quantityElement = button.parentElement.querySelector('.quantity-value');
    let quantity = parseInt(quantityElement.textContent);
    let priceElement=button.parentElement.parentElement.querySelector('.cart-item-price');
    let price=parseInt(priceElement.textContent);
    let oneunitprice;
    if(quantity===0){
        oneunitprice=price;
    }else{
       oneunitprice=price/quantity;
    }
    
    quantity++;

    quantityElement.textContent = quantity;
    priceElement.textContent=price+oneunitprice;
    updatetotalprice();

}

function decreaseQuantity(button) {
    let quantityElement = button.parentElement.querySelector('.quantity-value');
    let quantity = parseInt(quantityElement.textContent);
    let priceElement=button.parentElement.parentElement.querySelector('.cart-item-price')
    let price=parseInt(priceElement.textContent);
    let oneunitprice=price/quantity;
    if (quantity > 1) {
        quantity--;
        quantityElement.textContent = quantity;
        priceElement.textContent=price-oneunitprice;
        updatetotalprice();
    }
}

function applychanges(){
    let itemdetailselement=document.querySelectorAll('.cart-item-details');
    itemdetailselement.forEach(details=>{
        let keydetails=details.querySelector('.cart-item-name');
        let rest_id=keydetails.getAttribute('value');
        let food_id=keydetails.id;
        let food_quantity=details.querySelector('.quantity-value').textContent;
        console.log(rest_id,food_id,food_quantity);
        fetch(`/updatecartitems?user_id=${user_id}&rest_id=${rest_id}&food_id=${food_id}&food_quantity=${food_quantity}`)
        .then(response => response.text())
        .then(status => {
            if (status){
                console.log(status);
                window.location.href = "/third.html";
            }
        })
        .catch(error => {
            console.error('Error:', error);
        });
        });
    
}

function removeitem(button){
    let element=button.parentElement.querySelector(".cart-item-name");
    let rest_id=element.getAttribute('value');
    let food_id=element.id;
    fetch(`/deletecartitems?user_id=${user_id}&rest_id=${rest_id}&food_id=${food_id}`)
        .then(response => response.text())
        .then(status => {
            if (status){
                console.log(status);
                window.location.href = "/third.html";
            }
        })
        .catch(error => {
            console.error('Error:', error);
        });
}

function gotohome(){
    window.location.href = "/front.html";
}

function checkout(){
    let elem=document.querySelector(".cart-subtotal");
    if(elem.textContent==="Total Price : 0"){
        alert("Add items in the cart");
    }else{
        window.location.href = "/order.html";
    }   
}