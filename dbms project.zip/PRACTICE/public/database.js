var mysql=require('mysql');

var connection =mysql.createConnection({
    host:"localhost",
    user:"root",
    password:"varun@060",
    database:"LIBRARY",
    connectionLimit:10,
})

connection.connect(function(err){
    if(err){
        console.error("error connecting:"+err.stack);
    }
    console.log("connection as id"+connection.threadId);
})
connection.query('select * from BOOKS',function(err,results,fields){
    if(err){
        return console.log(err);
    }
    //method 1
    console.log(results);
    const myJson=JSON.stringify(results);
    const parse=JSON.parse(myJson);
    console.log(parse[1].BOOK_ID,parse[1].BOOK_NAME);
    //method 2
    results.forEach(result => {
        console.log(result);
        const book=result
        console.log(book["BOOK_ID"],book["BOOK_NAME"]);
        // var book_id=book["BOOK_ID"];
        // var book_name=book["BOOK_NAME"];
        // console.log(book_id,book_name);

    });
   
});
function button2(){
    alert("hi");
    connection.query('select * from BOOKS',function(err,results,fields){
        if(err){
            return console.log(err);
        }
        alert("hi");
        const str=JSON.stringify(results);
        const str_parse=JSON.parse(str);
        document.querySelector(".div_class").innerHTML='<ol><li>${str_parse[0].BOOK_ID}</li><li>${str_parse[0].BOOK_NAME}</li></ol>';
    })
}
 function button(){
    document.getElementById("btn").style.cssText="background-color:pink;width:80px;";
    document.getElementById("p_tag").innerHTML='<p>hi</p><p>bye</p>';
    
}