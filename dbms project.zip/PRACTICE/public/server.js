// server.js
//add web socket here
// const WebSocket = require('ws');
// const wss = new WebSocket.Server({ port: 8080 });


//to here
const express = require("express");
const bodyParser = require('body-parser');
const mysql = require("mysql");
const path = require('path');
const { CONNREFUSED } = require("dns");
const app = express();
app.use(express.static('public'));
const port = 3000;
app.use(bodyParser.json());
// MySQL database connection
const connection = mysql.createConnection({
    host: "localhost",
    user: "root",
    password: "varun@060",
    database: "LIBRARY",
});
connection.connect(function(err){
    if(err){
        console.error("error connecting:"+err.stack);
    }
    console.log("connection as id"+connection.threadId);
})
app.get("/main", (req, res) => {
    const indexPath = path.join(__dirname, 'loginpage.html');
    res.sendFile(indexPath);
});
// Route to fetch data from the database
app.get("/data", (req, res) => {
    
    // Example query to fetch data from a table
    console.log("entered");
    const query = "SELECT * FROM BOOKS";
    connection.query(query, (err, results) => {
        if (err) {
            console.error("Error executing MySQL query: " + err.stack);
            res.status(500).send("Internal Server Error");
            return;
        }
       
        // Generate HTML content with the fetched data
        const htmlContent = generateHTML(results);

        // Send the HTML content to the client
        res.send(htmlContent);
    });
});

app.post('/signUp', (req, res) => {
    console.log(req.body);
    let role=req.body.role;
    let username = req.body.username;
    let password = req.body.password;
    
    // Process the data
    const searchQuery="SELECT COUNT(*) as count FROM LIBRARY.LOGIN WHERE ROLE = ? AND USERNAME = ? AND PASSWORD = ?";
    connection.query(searchQuery,[role,username,password],async(err,results) =>{
        if (err) {
            console.error("Error executing MySQL query: " + err.stack);
            res.status(500).send("Internal Server Error");
            return;
        }
        console.log(results[0]["count"]);
        if(results[0]["count"]===0){
            const insertQuery="INSERT INTO LIBRARY.LOGIN VALUES(?,?,?)";
            connection.query(insertQuery,[role,username,password],(err,results) => {
                if (err) {
                    console.error("Error executing MySQL query: " + err.stack);
                    res.status(500).send("Internal Server Error");
                    return;
                }else{
                    console.log("insertion Success");
                    res.send("insertion Success");
                }
                
            })
        }else{
           res.send("alreadyexists")
        }
    });

  });

  app.post('/login', (req, res) => {
    console.log(req.body);
    let role=req.body.role;
    let username = req.body.username;
    let password = req.body.password;
    
    // Process the data
    let searchQuery="SELECT COUNT(*) as count FROM LIBRARY.LOGIN WHERE ROLE = ? AND USERNAME = ? AND PASSWORD = ?";
    connection.query(searchQuery,[role,username,password],(err,results) =>{
        if (err) {
            console.error("Error executing MySQL query: " + err.stack);
            res.status(500).send("Internal Server Error");
            return;
        }
        console.log(results[0]["count"]);
        if(results[0]["count"]===1){
            
           res.send(username)
        }
        else{
            res.send("invalid");
        }
        
    });

  });

// Function to generate HTML content
function generateHTML(data) {
    let html = "<ul>";
    data.forEach(item => {
        html += `<li>${item["BOOK_ID"]}: ${item["BOOK_NAME"]}</li>`;
    });
    html += "</ul>";
    return html;
}


app.get("/home", (req, res) => {
    
    // Example query to fetch data from a table
    
    const restaurant_query = "select * from library.restaurants;";
    connection.query(restaurant_query, (err, results) => {
        if (err) {
            console.error("Error executing MySQL query: " + err.stack);
            res.status(500).send("Internal Server Error");
            return;
        }
       
        // Generate HTML content with the fetched data
        const homeresContent = viewRes(results);

        // Send the HTML content to the client
        res.send(homeresContent);
    });
});

app.get('/menu', (req, res) => {
    let res_id = req.query.rest_id;
    let user_id=req.query.user_id;
    // Process the data
    console.log(res_id);
    let searchfood="select * from library.food where REST_ID = ?;";
    connection.query(searchfood,[res_id],(err,results) =>{
        if (err) {
            console.error("Error executing MySQL query: " + err.stack);
            res.status(500).send("Internal Server Error");
            return;
        }
        console.log(results);
        const foodmenu = menu(results);

        // Send the HTML content to the client
        res.send(foodmenu);
        
    });
    
  });


  app.get('/cart',(req,res) => {

    let rest_id=req.query.rest_id;
    let user_id=req.query.user_id;
    let food_id=req.query.food_id;
    let quantity=req.query.quantity;
    let cartSearchQuery="SELECT COUNT(*) as matchuser FROM LIBRARY.CART WHERE USER_ID=? AND REST_ID=? AND FOOD_ID=?;";
    let cartQuery="INSERT INTO LIBRARY.CART VALUES(?,?,?,?);";

    let cartupdateQuery="UPDATE LIBRARY.CART SET QUANTITY=QUANTITY+? WHERE USER_ID=? AND REST_ID=? AND FOOD_ID=?;";

    connection.query(cartSearchQuery,[user_id,rest_id,food_id],(err,results) =>{
        if (err) {
            console.error("Error executing MySQL query: " + err.stack);
            res.status(500).send("Internal Server Error");
            return;
        }
        if(results[0]["matchuser"]===0){
            connection.query(cartQuery,[user_id,rest_id,food_id,quantity],(err,results) =>{
                if (err) {
                    console.error("Error executing MySQL query: " + err.stack);
                    res.status(500).send("Internal Server Error");
                    return;
                }
                else{
                    res.send("new added");
                }
                  
            });
        }
        else{
            connection.query(cartupdateQuery,[quantity,user_id,rest_id,food_id],(err,results) =>{
                if (err) {
                    console.error("Error executing MySQL query: " + err.stack);
                    res.status(500).send("Internal Server Error");
                    return;
                }
                else{
                    res.send("updated");
                }
            });
        }
    });

  });


  app.get('/cartvalue',(req,res) => {
    
    let user_id=req.query.user_id;
    let cartvalueQuery="select sum(quantity) as total_quantity from library.cart where user_id=?;";
    let usersearchQuery="SELECT COUNT(*) as usercount FROM LIBRARY.CART WHERE USER_ID=?;";

    connection.query(usersearchQuery,[user_id],(err,results) =>{
        if (err) {
            console.error("Error executing MySQL query: " + err.stack);
            res.status(500).send("Internal Server Error");
            return;
        }
        if(results[0]["usercount"]===0){
            res.send("0");
        }
        else{
            connection.query(cartvalueQuery,[user_id],(err,results) =>{
                if (err) {
                    console.error("Error executing MySQL query: " + err.stack);
                    res.status(500).send("Internal Server Error");
                    return;
                }
                    console.log(results[0]["total_quantity"]);
                    res.send(results[0]["total_quantity"].toString());      
                });
        }
    });
    
  });

  app.get('/res_name',(req,res) =>{
    let rest_id=req.query.rest_id;
    let resnameQuery="select REST_NAME FROM LIBRARY.RESTAURANTS WHERE REST_ID=?;";
    connection.query(resnameQuery,[rest_id],(err,results) =>{
        if(err){
            console.error("Error executing MySQL query: " + err.stack);
            res.status(500).send("Internal Server Error");
            return;
        }
        console.log(results[0]["REST_NAME"]);
        res.send(results[0]["REST_NAME"]);
    });
  });


  app.get('/filtermenu', (req, res) => {
    let prices_type= req.query.pricetype;
    let food_type=req.query.foodtype;
    let rest_id=req.query.rest_id;

    console.log(prices_type);
    // Process the data
    let filterQuery="select * from library.food where REST_ID = ? ";
    if(food_type!="none"){
        filterQuery = filterQuery.concat("AND FOOD_TYPE= ?");
    }
    if(prices_type==='HL'){
        filterQuery = filterQuery.concat("ORDER BY FOOD_PRICE DESC");
    }
    else if(prices_type==='LH'){
        filterQuery = filterQuery.concat("ORDER BY FOOD_PRICE ASC");
    }
    console.log(prices_type,filterQuery);
    
    connection.query(filterQuery,[rest_id,food_type],(err,results) =>{
        if (err) {
            console.error("Error executing MySQL query: " + err.stack);
            res.status(500).send("Internal Server Error");
            return;
        }
        console.log(results);
        const foodmenu = menu(results);

        // Send the HTML content to the client
        res.send(foodmenu);
        
    });
    
  });


  app.get('/cartlist', (req, res) => {
    let user_id=req.query.user_id;
    // Process the data
    //console.log(res_id);
    let cartlist="SELECT F.FOOD_IMG,F.FOOD_NAME,C.QUANTITY,C.QUANTITY*F.FOOD_PRICE AS COST,C.FOOD_ID,C.REST_ID FROM LIBRARY.FOOD F,LIBRARY.CART C WHERE C.USER_ID=? AND F.FOOD_ID=C.FOOD_ID AND F.REST_ID=C.REST_ID;";
    connection.query(cartlist,[user_id],(err,results) =>{
        if (err) {
            console.error("Error executing MySQL query: " + err.stack);
            res.status(500).send("Internal Server Error");
            return;
        }
        console.log(results);
        const foodmenu = cartitems(results);

        // Send the HTML content to the client
        res.send(foodmenu);
        
    });
    
  });


  app.get('/updatecartitems',(req,res) => {
    
    let user_id=req.query.user_id;
    let rest_id=req.query.rest_id;
    let food_id=req.query.food_id;
    let food_quantity=req.query.food_quantity;
    
    let updatecartitemsQuery="UPDATE LIBRARY.CART SET QUANTITY=? WHERE USER_ID=? AND REST_ID=? AND FOOD_ID=?;";

    connection.query(updatecartitemsQuery,[food_quantity,user_id,rest_id,food_id],(err,results) =>{
        if (err) {
            console.error("Error executing MySQL query: " + err.stack);
            res.status(500).send("Internal Server Error");
            return;
        }
        res.send("cart items updated");
    });
    
  });


  app.get('/deletecartitems',(req,res) => {
    
    let user_id=req.query.user_id;
    let rest_id=req.query.rest_id;
    let food_id=req.query.food_id;
    
    let deletecartitemsQuery="DELETE FROM LIBRARY.CART WHERE USER_ID=? AND REST_ID=? AND FOOD_ID=?;";

    connection.query(deletecartitemsQuery,[user_id,rest_id,food_id],(err,results) =>{
        if (err) {
            console.error("Error executing MySQL query: " + err.stack);
            res.status(500).send("Internal Server Error");
            return;
        }
        res.send("item deleted");
    });
    
  });


  app.get('/addlogindetails',(req,res) => {
    
    let user_id=req.query.user_id;
    let name=req.query.name;
    let role=req.query.role;
    let address=req.query.address;
    let phone=req.query.phone;
    let gender=req.query.gender;
    console.log(user_id,name,role,address,phone,gender);
    let userdetailsQuery="INSERT INTO LIBRARY.USERDETAILS VALUES(?,?,?,?,?,?)";

    connection.query(userdetailsQuery,[user_id,name,address,gender,phone,role],(err,results) =>{
        if (err) {
            console.error("Error executing MySQL query: " + err.stack);
            res.status(500).send("Internal Server Error");
            return;
        }
        res.send("user details added successfully");
    });
    
  });

  app.get('/removelogin',(req,res) => {
    
    let deleteQuery="DELETE FROM LIBRARY.orders;";

    connection.query(deleteQuery,(err,results) =>{
        if (err) {
            console.error("Error executing MySQL query: " + err.stack);
            res.status(500).send("Internal Server Error");
            return;
        }
        res.send("deletion success");
    });
    
  });

  app.get('/checkout',(req,res) => {
    let user_id=req.query.user_id;
    let takecartitemsQuery="SELECT F.FOOD_NAME,C.QUANTITY,R.REST_NAME,F.FOOD_PRICE,C.QUANTITY*F.FOOD_PRICE AS TOTALCOST FROM LIBRARY.FOOD F,LIBRARY.CART C,LIBRARY.RESTAURANTS R WHERE C.USER_ID=? AND F.FOOD_ID=C.FOOD_ID AND F.REST_ID=C.REST_ID AND F.REST_ID=R.REST_ID;";

    connection.query(takecartitemsQuery,[user_id],(err,results) =>{
        if (err) {
            console.error("Error executing MySQL query: " + err.stack);
            res.status(500).send("Internal Server Error");
            return;
        }
        let sendData=fillorder(results);
        res.send(sendData);
    });
    
  });

  app.get('/addtoorder',(req,res) => {
    
    let user_id=req.query.user_id;
    let inserttocartQuery="INSERT INTO LIBRARY.ORDERS(USER_ID,ORDER_DATE,ORDER_STATUS) VALUES(?,?,?);"
    let orderidQuery="SELECT MAX(ORDER_ID) AS REQ_ID FROM LIBRARY.ORDERS WHERE USER_ID=?;";
    let insertToorderitemsQuery="INSERT INTO LIBRARY.ORDER_ITEMS (SELECT ?,REST_ID,FOOD_ID,QUANTITY FROM LIBRARY.CART WHERE USER_ID=?);";
    let deletecartitemsQuery="DELETE FROM LIBRARY.CART WHERE USER_ID=?;";

    let order_id;
    const currentDate = new Date();
    const formattedDate = currentDate.toISOString().slice(0, 10);
    console.log(formattedDate); 

    connection.query(inserttocartQuery,[user_id,formattedDate,"ACTIVE"],(err,results) =>{
        if (err) {
            console.error("Error executing MySQL query: " + err.stack);
            res.status(500).send("Internal Server Error");
            return;
        }
    });

    connection.query(orderidQuery,[user_id],(err,results) =>{
        if (err) {
            console.error("Error executing MySQL query: " + err.stack);
            res.status(500).send("Internal Server Error");
            return;
        }
        order_id=results[0]["REQ_ID"];
        order_id=order_id.toString();
        console.log("orderid generation",order_id);
        connection.query(insertToorderitemsQuery,[order_id,user_id],(err,results) =>{
            if (err) {
                console.error("Error executing MySQL query: " + err.stack);
                res.status(500).send("Internal Server Error");
                return;
            }
            connection.query(deletecartitemsQuery,[user_id],(err,results) =>{
                if (err) {
                    console.error("Error executing MySQL query: " + err.stack);
                    res.status(500).send("Internal Server Error");
                    return;
                }
                res.send(order_id);
            });
        });
        
    });
    
  });


  app.get('/orderslistemp',(req,res) => {
    
    let takeactiveordersQuery="SELECT U.ADDRESS,O.ORDER_ID FROM LIBRARY.ORDERS O,LIBRARY.USERDETAILS U WHERE ORDER_STATUS='ACTIVE' AND O.USER_ID=U.USER_ID;";
    let checkordersQuery="SELECT COUNT(*) AS ORDERS_COST FROM LIBRARY.ORDERS WHERE ORDER_STATUS='ACTIVE';";

    connection.query(checkordersQuery,(err,results) =>{
        if (err) {
            console.error("Error executing MySQL query: " + err.stack);
            res.status(500).send("Internal Server Error");
            return;
        }
        if(results[0]["ORDERS_COST"]!=0){
            connection.query(takeactiveordersQuery,(err,results) =>{
                if (err) {
                    console.error("Error executing MySQL query: " + err.stack);
                    res.status(500).send("Internal Server Error");
                    return;
                }
                let sendData=insertorders(results);
                res.send(sendData);
            });
        }
    });
    
  });

  app.get('/ordersitemstableemp',(req,res) => {
    let order_id=req.query.order_id;
    // let empordertableQuery="SELECT distinct F.FOOD_NAME,R.REST_NAME,OI.QUANTITY,F.FOOD_PRICE,F.FOOD_PRICE*OI.QUANTITY AS TOTAL_PRICE FROM LIBRARY.ORDER_ITEMS OI,LIBRARY.FOOD F,LIBRARY.ORDERS O,LIBRARY.RESTAURANTS R WHERE OI.ORDER_ID=? AND (OI.REST_ID=R.REST_ID AND OI.FOOD_ID=F.FOOD_ID AND F.REST_ID=R.REST_ID);";
    let empordertableQuery="SELECT  F.FOOD_NAME,R.REST_NAME,OI.QUANTITY,F.FOOD_PRICE,F.FOOD_PRICE*OI.QUANTITY AS TOTAL_PRICE FROM LIBRARY.ORDER_ITEMS OI INNER JOIN LIBRARY.FOOD F ON OI.FOOD_ID=F.FOOD_ID AND OI.REST_ID=F.REST_ID INNER JOIN LIBRARY.RESTAURANTS R ON R.REST_ID=F.REST_ID WHERE OI.ORDER_ID=?;";
    connection.query(empordertableQuery,[order_id],(err,results) =>{
        if (err) {
            console.error("Error executing MySQL query: " + err.stack);
            res.status(500).send("Internal Server Error");
            return;
        }
        let sendData=fillemptable(results);
        res.send(sendData);
    });
    
  });

  app.get('/orderaccept',(req,res) => {

    let emp_id=req.query.emp_id;
    let order_id=req.query.order_id;
    let addemp_idQuery="UPDATE LIBRARY.ORDERS SET EMP_ID = ?,ORDER_STATUS=? WHERE ORDER_ID = ?;";

    connection.query(addemp_idQuery,[emp_id,"ACCEPT",order_id],(err,results) =>{
        if (err) {
            console.error("Error executing MySQL query: " + err.stack);
            res.status(500).send("Internal Server Error");
            return;
        }
        res.send("employee id added to the table");
    });
    
  });

  app.get('/orderstatuscus',(req,res) => {

   
    let order_id=req.query.order_id;
    let orderStatusQuery="SELECT ORDER_STATUS FROM LIBRARY.ORDERS WHERE ORDER_ID=?;";

    connection.query(orderStatusQuery,[order_id],(err,results) =>{
        if (err) {
            console.error("Error executing MySQL query: " + err.stack);
            res.status(500).send("Internal Server Error");
            return;
        }
        res.send(results[0]["ORDER_STATUS"]);
    });
    
  });

  app.get('/changeorderstatus',(req,res) => {

    let order_statusbyemp=req.query.order_status;
    let order_id=req.query.order_id;
    let changedorderStatusQuery="UPDATE LIBRARY.ORDERS SET ORDER_STATUS= ? WHERE ORDER_ID = ?;";

    connection.query(changedorderStatusQuery,[order_statusbyemp,order_id],(err,results) =>{
        if (err) {
            console.error("Error executing MySQL query: " + err.stack);
            res.status(500).send("Internal Server Error");
            return;
        }
       // dynamicStatusUpdate(order_statusbyemp);
        res.send("order status changed");
    });
    
  });

  app.get('/fetchcustomerdetails',(req,res) => {
    let order_id=req.query.order_id;
    let custdetailsQuery="SELECT U.NAME,U.PHONE,U.ADDRESS FROM LIBRARY.USERDETAILS U,library.ORDERS O WHERE O.ORDER_ID=? AND O.USER_ID=U.USER_ID;";

    connection.query(custdetailsQuery,[order_id],(err,results) =>{
        if (err) {
            console.error("Error executing MySQL query: " + err.stack);
            res.status(500).send("Internal Server Error");
            return;
        }
        let sendData=fillcustdetails(results);
        res.send(sendData);
    });
    
  });

  app.get('/fetchempdetails',(req,res) => {
    let order_id=req.query.order_id;
    let custdetailsQuery="SELECT E.NAME,E.PHONE FROM LIBRARY.USERDETAILS E,library.ORDERS O WHERE O.ORDER_ID=? AND O.EMP_ID=E.USER_ID AND E.ROLE='employee';";

    connection.query(custdetailsQuery,[order_id],(err,results) =>{
        if (err) {
            console.error("Error executing MySQL query: " + err.stack);
            res.status(500).send("Internal Server Error");
            return;
        }
        let sendData=fillempdetails(results);
        res.send(sendData);
    });
    
  });

// ... (other routes and server setup)

app.listen(port, () => {
    console.log(`Server is running on http://localhost:${port}`);
});

function viewRes(data){
    let html = "";
    data.forEach(item => {
        let img_loc="assests\\".concat(item['REST_IMG']);
        //${img_loc} + ${item['REST_IMG']}
        //let rest_id=item['REST_ID'];
        html += `<li class='restaurant-item' id=${item['REST_ID']}>
                <div class="card-first-div">
                    <img src="${img_loc}" alt="" class="card-image">
                </div>
                <div class="restaurant-info">
                    <h3>${item['REST_NAME']}</h3>
                    <p>${item['REST_LOC']}</p>
                    <p>4.5 35-40 mins</p>
                    <button class="order-button" onclick='open_food("${item['REST_ID']}");');'>Order Now</button>
                </div>
                
                </li>`;

    });
    
    return html;
}
function menu(data){
    let html = "";
    data.forEach(item => {
        let img_loc="assests\\".concat(item['FOOD_IMG']);
        //${img_loc} + ${item['REST_IMG']}
        html += `<div class="product">
                    <img src="${img_loc}" alt="Product 1">
                    <div class="details">
                        <h3>${item['FOOD_NAME']}</h3>
                        <p>Price: ${item['FOOD_PRICE']}</p>
                        <button class="add-btn" onclick='addToCart(this,"${item['FOOD_ID']}")'>Add to Cart</button>
                        <div class="quantity">
                            <button class="quantity-btn decrease" onclick='decreaseQuantity(this)'>-</button>
                            <span class="quantity-value">0</span>
                            <button class="quantity-btn increase" onclick='increaseQuantity(this)'>+</button>
                        </div>
                    </div>
                </div>`;

    });
    
    return html;
}

function cartitems(data){
    let html = '<div class="cart-header"> <p>Food Cart</p><button class="apply-button" onclick="applychanges()">Apply</button></div>';
    data.forEach(item => {
        let img_loc="assests\\".concat(item['FOOD_IMG']);
        //${img_loc} + ${item['REST_IMG']}
        html += `<div class="cart-item">
        <div class="cart-item-image">
          <img src="${img_loc}" alt="Apple Juice">
        </div>
        <div class="cart-item-details">
          <div class="cart-item-name" id="${item['FOOD_ID']}" value="${item['REST_ID']}">${item['FOOD_NAME']}</div>
          <div class="cart-item-quantity">
            <button class="quantity-button decrease" onclick='decreaseQuantity(this)'>-</button>
            <span class="quantity-value">${item['QUANTITY']}</span>
            <button class="quantity-button increase" onclick='increaseQuantity(this)'>+</button>
          </div>
          <div class="cart-item-price">${item['COST']}</div>
          <button class="remove-button" onclick='removeitem(this)'>Remove</button>
          
        </div>
      </div>`;

    });
    html+='<div class="cart-subtotal">Sub-Total: 2 items $6.18</div><button class="checkout-button" onclick="checkout()">Checkout</button></div>';
    return html;
}

function fillorder(data){
    let html='<thead><tr><th>Product</th><th>Restaurant</th><th>Quantity</th><th>Unit Price</th><th>Total</th></tr></thead><tbody>';
    data.forEach(item=>{

        html+=`<tr><td>${item['FOOD_NAME']}</td><td>${item['REST_NAME']}</td><td>${item['QUANTITY']}</td><td>${item['FOOD_PRICE']}</td><td class="item_value">${item['TOTALCOST']}</td></tr>`;
    });
    html+='<tfoot><tr><td colspan="4">Total</td><td class="total_cost">$36.72</td></tr></tfoot>';
    return html;
}

function insertorders(data){
    let html='<div class="top-heading">ORDERS</div>';
    data.forEach(item=>{

        html+=`<div class="each_order" id="${item["ORDER_ID"]}">
        <div>${item["ADDRESS"]}</div>
        <button onclick='fetchorderdetails(this)'>Accept</button>
      </div>`;
    });
    return html;
}

function fillemptable(data){
    let html='<thead><tr><th>Product</th><th>Restaurant</th><th>Quantity</th><th>Unit Price</th><th>Total</th></tr></thead><tbody>';
    data.forEach(item=>{

        html+=`<tr>
        <td>${item["FOOD_NAME"]}</td>
        <td>${item["REST_NAME"]}</td>
        <td>${item["QUANTITY"]}</td>
        <td>${item["FOOD_PRICE"]}</td>
        <td class="item_value">${item["TOTAL_PRICE"]}</td>
      </tr>`;
    });
    html+='</tbody><tfoot><tr><td colspan="4">Total</td><td class="total_value">$36.72</td></tr></tfoot>'
    return html;
}

function fillcustdetails(data){
    let html='';
    data.forEach(item=>{

        html+=`<h2 class="member-name">${item["NAME"]}</h2>
        <p class="member-phone">Phone Number: ${item["PHONE"]}</p>
        <p class="member-address">Address: ${item["ADDRESS"]}</p>`;
    });
    
    return html;
}

function fillempdetails(data){
    let html='';
    data.forEach(item=>{

        html+=`<h2 class="member-name">${item["NAME"]}</h2>
        <p class="member-phone">Phone Number: ${item["PHONE"]}</p>`;
    });
    
    return html;
}


    // wss.on('connection', function connection(ws) {
    //     ws.on('message', function incoming(message) {
    //         wss.clients.forEach(function each(client) {
    //             if (client !== ws && client.readyState === WebSocket.OPEN) {
    //               client.send(message);
    //             }
    //           });
    //         });
    //       });
