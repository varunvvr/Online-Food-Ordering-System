
let id=sessionStorage.getItem('res_id');
let user_id=sessionStorage.getItem('user_id');

let cartCount =0;

function addToCart(button,food_id) {
    let no_of_items=parseInt(button.parentElement.querySelector('.quantity-value').textContent);
    
    cartCount+=parseInt(no_of_items);
    console.log("intial",no_of_items,cartCount);
    updateCartCount();
    //cart_value(user_id);
    fetch(`/cart?rest_id=${id}&user_id=${user_id}&food_id=${food_id}&quantity=${no_of_items}`)
    .then(response => response.text())
    .then(status => {
        if (status){
            console.log(status);
        }
    })
    .catch(error => {
        console.error('Error:', error);
    });
}

function decreaseQuantity(button) {
    let quantityElement = button.parentElement.querySelector('.quantity-value');
    let quantity = parseInt(quantityElement.textContent);
    if (quantity > 0) {
        quantity--;
        quantityElement.textContent = quantity;
    }
}

function increaseQuantity(button) {
    let quantityElement = button.parentElement.querySelector('.quantity-value');
    let quantity = parseInt(quantityElement.textContent);
    quantity++;
    quantityElement.textContent = quantity;
}

function updateCartCount() {
    document.querySelector('.cart-count').textContent = cartCount;
    console.log("in the update function",cartCount);
}


fetch(`/menu?rest_id=${id}&user_id=${user_id}`)
.then(response => response.text())
.then(htmlContent => {
    console.log(htmlContent); 
    // Insert the HTML content into a container element
    const container = document.querySelector(".products-container");
    container.innerHTML = htmlContent;
    // Redirect to another page
    rest_name(id);
    cart_value(user_id);
    
 })
.catch(error => {
    console.error("Error:", error);
});

function rest_name(id){
    console.log("enetered to the functioon");
    fetch(`/res_name?rest_id=${id}`)
    .then(response => response.text())
    .then(status =>{
        if(status){
            document.querySelector(".res_name").textContent=status.concat(" FOODS");
        }
    })
    .catch(error =>{
        console.error('Error:', error);
    });
}

function cart_value(user_id){
    fetch(`/cartvalue?user_id=${user_id}`)
    .then(response => response.text())
    .then(status => {
        if (status){
            document.querySelector(".cart-count").textContent=status;
            cartCount=parseInt(status);
            console.log("in the cart function",status);
        }
    })
    .catch(error => {
        console.error('Error:', error);
    });
}
// .then(response => {
//     // Check if the response is successful
//     if (!response.ok) {
//         throw new Error('Network response was not ok');
//     }
//     // Parse the response as text
//     return response.text();
// })
// .then(data => {
//     // Parse the HTML content
//     const parser = new DOMParser();
//     const htmlDoc = parser.parseFromString(data, 'text/html');
//     const productsContainer = htmlDoc.querySelector('.products-container');

//     // Update the cart count value
//     const cartCount = htmlDoc.querySelector('.cart-count').textContent;
//     document.querySelector(".cart-count").textContent = cartCount;

//     // Insert the HTML content into a container element
//     const container = document.querySelector(".products-container");
//     container.innerHTML = productsContainer.innerHTML;
// })
// .catch(error => {
//     console.error("Error:", error);
// });




// wriet the function for the radio button

function filterselection(){
    let fooddropdown = document.getElementById("food-type");
    let pricedropdown=document.getElementById("price-type");
    let foodselectedValue = fooddropdown.options[fooddropdown.selectedIndex].value;
    let priceselectedValue = pricedropdown.options[pricedropdown.selectedIndex].value;
    let filter={
        "food_type":foodselectedValue,
        "price_type":priceselectedValue
    }
    // Use the selected value as needed
    console.log("filtered value", filter);

    fetch(`/filtermenu?foodtype=${foodselectedValue}&pricetype=${priceselectedValue}&rest_id=${id}`)
    .then(response => response.text())
    .then(htmlContent => {
    console.log(htmlContent); 
    // Insert the HTML content into a container element
    const container = document.querySelector(".products-container");
    container.innerHTML = htmlContent;
    // Redirect to another page
    //rest_name(id);
    //cart_value(user_id);
    
    })
    .catch(error => {
        console.error("Error:", error);
    });
}

function movetocart(){
    window.location.href = "/third.html";
}

function gotoHome(){
    window.location.href = "/front.html";
}

document.querySelector(".quantity-value").textContent=cartCount;