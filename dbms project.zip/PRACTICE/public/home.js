
let user_id=sessionStorage.getItem('user_id');

fetch("/home")
.then(response => response.text())
.then(htmlContent => {
    // Insert the HTML content into a container element
    const container = document.querySelector(".restaurant-list");
    container.innerHTML = htmlContent;
})
.catch(error => {
    console.error("Error:", error);
});

fetch(`/cartvalue?user_id=${user_id}`)
    .then(response => response.text())
    .then(status => {
        if (status){
            document.querySelector(".cart-count").textContent=status;
        }
    })
    .catch(error => {
        console.error('Error:', error);
    });

function open_food(id){
    sessionStorage.setItem('res_id', id);
    
    window.location.href = "/second.html";
}

function logout(){
    window.location.href = "/loginpage.html"
}

function gotocart(){
    window.location.href = "/third.html"
}